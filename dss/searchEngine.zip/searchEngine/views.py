from django.shortcuts import render
from searchEngine.models import searchResult
from requests import Session
import json
from rest_framework.decorators import api_view
from requests.exceptions import ConnectionError, Timeout, TooManyRedirects
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from searchEngine.keywords import result
# Create your views here.
from bson import json_util, ObjectId
import pymongo
print(len(result))
myclient = pymongo.MongoClient("mongodb+srv://dss:P8NKXqiTp3tN3vNt@dss-search.ujjrk5w.mongodb.net/?retryWrites=true&w=majority")
mydb = myclient["dss-search"]
# print(mydb)
# mydb.create_collection('searchLinks')
mycol=mydb['searchResult']
# print(mycol)

@api_view(['GET'])
def searchQuery(request):
    q= request.GET.get('q')
    print('HII')
    result = mycol.aggregate([
        {
            '$search': {
                'index': 'default', 
                'text': {
                    'query': q, 
                    'path': 'searchItem', 
                    'fuzzy': {
                        'maxEdits': 2
                    }
                }
            }
        }, {
            '$project': {
                '_id': 1, 
                'searchItem': 1, 
                'description': 1, 
                'score': {
                    '$meta': 'searchScore'
                }
            }
        }
    ])
    r=[]
    for i in result:
        print(i)
        r.append(i)
    d= json.loads(json_util.dumps(r))
    return JsonResponse(d,safe=False)
@api_view(["GET"])
def scrape(request):
    # data= JSONParser().parse(request)
    # data = request.data
    try:
        # mycol.delete_many({})
        links= mydb['searchLinks']
        print(len(result))
        for q in result:
            for i in range(2):
                BASE_URL = "https://www.googleapis.com/customsearch/v1?key=AIzaSyBcEBRIr1tmY_ZxuRgNN6cA1rLuhpr-KiA&cx=7692c9c0d3459418f&q="+ q
                if(i==1):
                    BASE_URL= BASE_URL+'&start=11'
                print(BASE_URL)
                session = Session()
                print(i)
                response = session.get(BASE_URL)
                data= response.json()
                print(data)
                try:
                    for i in data['items']:
                        # try:
                        x=links.find_one({'link':i['link']})
                        if x:
                            print('FOUNDD')
                        else:
                            print('NOT FOUND')      
                            obj={}
                            try:
                                obj['title']=i['title']
                            except:
                                print(1)
                            try:
                                obj['snippet']= i['snippet']
                            except:
                                print(2)
                            try: 
                                obj['link']= i['link']
                            except:
                                print(3)
                            # if(('pagemap' in i)  & ('metatags' in i['pagemap']) & ('og:description' in i['pagemap']['metatags'][0]) ):
                            try:
                                obj['description']=i['pagemap']['metatags'][0]['og:description']
                            except:
                                print('none')
                            obj['searchItem']= json.dumps(i)
                            a = mycol.insert_one(obj)
                            b= links.insert_one({'link':i['link']})
                            print(a.inserted_id)
                except:
                    print('nan')
        return JsonResponse({'message':'Added Successfully'}, safe= False)
    except (ConnectionError, Timeout, TooManyRedirects) as e:
        print(e)
        return JsonResponse('DID not get DATA', safe=False)
