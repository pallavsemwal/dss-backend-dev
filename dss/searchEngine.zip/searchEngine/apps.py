from django.apps import AppConfig


class SearchengineConfig(AppConfig):
    name = 'searchEngine'
